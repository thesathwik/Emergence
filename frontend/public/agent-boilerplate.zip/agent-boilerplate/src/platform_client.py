import requests
import json

class PlatformClient:
    def __init__(self, config):
        self.config = config
        self.instance_id = None
        self.platform_url = config.get("platform_url", "https://emergence-production.up.railway.app")
        
    def register(self):
        """Register agent with platform"""
        try:
            response = requests.post(
                f"{self.platform_url}/api/webhook/register",
                json={
                    "agent_id": self.config.get("agent_id"),
                    "instance_name": self.config.get("instance_name", "agent-1"),
                    "endpoint_url": self.config.get("endpoint_url", "http://localhost:5000")
                },
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                self.instance_id = data.get("instance_id")
                return True
            else:
                print(f"Registration failed: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"Registration error: {e}")
            return False
    
    def ping(self, status="running", metadata=None):
        """Send health check to platform"""
        if not self.instance_id:
            return
            
        try:
            requests.post(
                f"{self.platform_url}/api/webhook/ping",
                json={
                    "instance_id": self.instance_id,
                    "status": status,
                    "metadata": metadata or {}
                },
                timeout=5
            )
        except Exception as e:
            # Silently fail - don't crash agent if platform is down
            pass
