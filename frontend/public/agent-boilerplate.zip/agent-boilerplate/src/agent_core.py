class AgentCore:
    def __init__(self, config):
        """
        Initialize your agent here.
        The config contains all settings from config.json
        """
        self.config = config
        
        # TODO: Add your initialization code here
        # Example: self.email_client = EmailClient(config['email'])
        # Example: self.ai_model = OpenAI(config['openai_key'])
        
        print("🔧 Agent initialized - add your setup code in __init__")
        
    def run_cycle(self):
        """
        This method runs every 30 seconds.
        Add your main agent logic here.
        
        Examples:
        - Check for new emails and respond
        - Generate social media posts
        - Process data files
        - Monitor websites for changes
        """
        
        # TODO: Replace this with your agent logic
        print("⚡ Agent cycle running - add your logic in run_cycle()")
        
        # Example agent logic:
        # new_emails = self.check_emails()
        # for email in new_emails:
        #     response = self.generate_response(email)
        #     self.send_reply(email, response)
        
        # Example return metadata (optional):
        # return {"emails_processed": len(new_emails)}
