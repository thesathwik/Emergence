# Agent Boilerplate

## Setup
1. Edit `src/agent_core.py` - add your agent logic
2. Update `agent.json` with your agent details  
3. Zip entire folder and upload to marketplace

## Test Locally
```bash
pip install -r requirements.txt
python src/main.py
```

Done!
