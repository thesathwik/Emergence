import requests
import json

class PlatformClient:
    def __init__(self, config):
        self.config = config
        self.instance_id = None
        self.platform_url = config.get("platform_url", "https://emergence-production.up.railway.app")
        self.agent_core = None  # Will be set by main.py
        
    def register(self):
        """Register agent with platform"""
        try:
            payload = {
                "agent_id": self.config.get("agent_id"),
                "instance_name": self.config.get("instance_name", "agent-1"),
                "endpoint_url": self.config.get("endpoint_url", "http://localhost:5000")
            }
            
            # Add capabilities if agent_core is available
            if self.agent_core:
                payload["capabilities"] = self.agent_core.declare_capabilities()
                payload["methods"] = self.agent_core.declare_methods()
            
            response = requests.post(
                f"{self.platform_url}/api/webhook/register",
                json=payload,
                timeout=10
            )
            
            if response.status_code == 200:
                data = response.json()
                self.instance_id = data.get("instance_id")
                return True
            else:
                print(f"Registration failed: {response.status_code}")
                return False
                
        except Exception as e:
            print(f"Registration error: {e}")
            return False
    
    def ping(self, status="running", metadata=None):
        """Send health check to platform"""
        if not self.instance_id:
            return
            
        try:
            requests.post(
                f"{self.platform_url}/api/webhook/ping",
                json={
                    "instance_id": self.instance_id,
                    "status": status,
                    "metadata": metadata or {}
                },
                timeout=5
            )
        except Exception as e:
            # Silently fail - don't crash agent if platform is down
            pass
    
    def find_agents(self, capability=None, exclude_self=True):
        """Find other agents by capability"""
        try:
            params = {}
            if capability:
                params["capability"] = capability
            if exclude_self and self.instance_id:
                params["exclude"] = self.instance_id
                
            response = requests.get(
                f"{self.platform_url}/api/agents/discover",
                params=params,
                timeout=10
            )
            
            if response.status_code == 200:
                return response.json().get("agents", [])
            else:
                print(f"Agent discovery failed: {response.status_code}")
                return []
                
        except Exception as e:
            print(f"Agent discovery error: {e}")
            return []
    
    def call_agent(self, agent_id, method, data=None, timeout=30):
        """Call another agent's method"""
        try:
            response = requests.post(
                f"{self.platform_url}/api/agents/{agent_id}/call",
                json={
                    "method": method,
                    "data": data or {},
                    "sender_id": self.instance_id
                },
                timeout=timeout
            )
            
            if response.status_code == 200:
                return response.json()
            else:
                print(f"Agent call failed: {response.status_code}")
                return {"error": f"Call failed with status {response.status_code}"}
                
        except Exception as e:
            print(f"Agent call error: {e}")
            return {"error": str(e)}
