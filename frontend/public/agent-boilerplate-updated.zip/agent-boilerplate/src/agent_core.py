class AgentCore:
    def __init__(self, config):
        """
        Initialize your agent here.
        The config contains all settings from config.json
        """
        self.config = config
        self.platform_client = None  # Will be set by main.py
        
        # TODO: Add your initialization code here
        # Example: self.email_client = EmailClient(config['email'])
        # Example: self.ai_model = OpenAI(config['openai_key'])
        
        print("🔧 Agent initialized - add your setup code in __init__")
    
    def declare_capabilities(self):
        """
        DEVELOPERS: Override this method to declare what your agent can do.
        Return a list of capabilities your agent provides.
        
        Available capabilities:
        - "email-processing"
        - "data-processing"  
        - "customer-support"
        - "content-generation"
        - "web-scraping"
        - "api-integration"
        - "file-processing"
        - "scheduling"
        - "database"
        - "monitoring"
        - "social-media"
        - "image-processing"
        - "nlp"
        - "ml-prediction"
        - "workflow-automation"
        """
        # TODO: Replace with your agent's actual capabilities
        return ["general-assistance"]
    
    def declare_methods(self):
        """
        DEVELOPERS: Override this to declare what methods other agents can call.
        Return a dictionary of method_name -> description.
        """
        # TODO: Replace with your agent's actual methods
        return {
            "help": "Provides general assistance",
            "status": "Returns current agent status"
        }
    
    def find_agents(self, capability=None, exclude_self=True):
        """
        Helper method to find other agents by capability.
        
        Args:
            capability (str): Required capability (e.g., "email-processing")
            exclude_self (bool): Don't include this agent in results
            
        Returns:
            list: Available agents matching criteria
        """
        if not self.platform_client:
            print("❌ Platform client not available")
            return []
            
        return self.platform_client.find_agents(capability, exclude_self)
    
    def call_agent(self, agent_id, method, data=None, timeout=30):
        """
        Helper method to call another agent's method.
        
        Args:
            agent_id (str): Target agent instance ID
            method (str): Method name to call
            data (dict): Data to send to the agent
            timeout (int): Timeout in seconds
            
        Returns:
            dict: Response from the target agent
        """
        if not self.platform_client:
            print("❌ Platform client not available")
            return None
            
        return self.platform_client.call_agent(agent_id, method, data, timeout)
    
    def handle_agent_call(self, method, data):
        """
        DEVELOPERS: Override this to handle calls from other agents.
        
        Args:
            method (str): Method name being called
            data (dict): Data sent by calling agent
            
        Returns:
            dict: Response to send back to calling agent
        """
        # TODO: Add your inter-agent method handling here
        
        if method == "help":
            return {"message": "This is a basic agent, override handle_agent_call for custom methods"}
        elif method == "status":
            return {"status": "running", "capabilities": self.declare_capabilities()}
        else:
            return {"error": f"Unknown method: {method}"}
        
    def run_cycle(self):
        """
        This method runs every 30 seconds.
        Add your main agent logic here.
        
        COLLABORATION EXAMPLES:
        
        # Find agents that can process emails
        email_agents = self.find_agents("email-processing")
        
        # Call another agent
        if email_agents:
            response = self.call_agent(email_agents[0]["instance_id"], "process_email", {
                "subject": "Customer inquiry",
                "body": "How do I return an item?"
            })
            print(f"Email agent response: {response}")
        
        # Find agents by multiple criteria
        support_agents = self.find_agents("customer-support")
        for agent in support_agents:
            status = self.call_agent(agent["instance_id"], "status")
            print(f"Agent {agent['instance_name']} status: {status}")
        """
        
        # TODO: Replace this with your agent logic
        print("⚡ Agent cycle running - add your logic in run_cycle()")
        
        # Example agent logic:
        # new_emails = self.check_emails()
        # for email in new_emails:
        #     if "billing" in email.content.lower():
        #         # Find billing agents to help
        #         billing_agents = self.find_agents("billing")
        #         if billing_agents:
        #             response = self.call_agent(
        #                 billing_agents[0]["instance_id"], 
        #                 "handle_billing_query", 
        #                 {"email_content": email.content}
        #             )
        #             self.send_email_reply(email, response["message"])
        #     else:
        #         # Handle myself
        #         self.handle_general_support(email)
        
        # Example return metadata (optional):
        # return {"emails_processed": len(new_emails)}